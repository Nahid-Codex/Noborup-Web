=====================================================================
NOBORUP - 100% READY-TO-USE & READY-TO-DEPLOY WEBSITE
=====================================================================

NO "npm install" OR "npm run build" NEEDED!
All files in this folder are already compiled and ready for production.

---------------------------------------------------------------------
OPTION 1: UPLOAD TO ANY WEB HOSTING (cPanel / Hostinger / Namecheap)
---------------------------------------------------------------------
1. Open your hosting File Manager -> go to `public_html`.
2. Upload all files from this ZIP directly into `public_html`
   (including `index.html`, `assets/`, and `.htaccess`).
3. Done! Your website is live immediately.

---------------------------------------------------------------------
OPTION 2: DRAG & DROP FREE HOSTING (Netlify / Cloudflare Pages / Vercel)
---------------------------------------------------------------------
1. Go to https://app.netlify.com/drop
2. Drag and drop this extracted folder (or ZIP) onto the page.
3. Done! Your website will be live in 5 seconds.

---------------------------------------------------------------------
OPTION 3: RUN ON YOUR WINDOWS PC (1-CLICK)
---------------------------------------------------------------------
1. Extract this ZIP folder anywhere on your PC.
2. Double-click `RUN-READY-WEBSITE.bat`.
3. It will open http://localhost:4173 in your browser automatically!
