@echo off
title Noborup Ready Website Server
echo ===================================================
echo   Starting Noborup Ready Website (No npm install!)
echo ===================================================
echo.
echo Opening http://localhost:4173 in your browser...
start http://localhost:4173
npx --yes serve -s . -l 4173
pause
