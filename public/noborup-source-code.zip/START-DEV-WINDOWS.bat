@echo off
title Noborup Development Server
echo ===================================================
echo   Installing packages (with legacy-peer-deps)...
echo ===================================================
call npm install --legacy-peer-deps
echo.
echo ===================================================
echo   Starting Noborup Local Dev Server...
echo ===================================================
start http://localhost:3000
call npm run dev
pause
